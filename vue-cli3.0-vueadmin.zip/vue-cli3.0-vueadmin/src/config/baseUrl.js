const baseUrl = process.env.NODE_ENV === 'production' ? '/' : '/api'
export default baseUrl
