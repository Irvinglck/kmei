<template>
    <div>
      <p>home</p>
    </div>
</template>

<script>
export default {
    data() {
        return {}
    }
}
</script>
